-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-11-2017 a las 22:10:18
-- Versión del servidor: 10.1.24-MariaDB
-- Versión de PHP: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tos`
--
CREATE DATABASE IF NOT EXISTS `tos` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci;
USE `tos`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tos_base`
--

CREATE TABLE `tos_base` (
  `id` mediumint(9) NOT NULL,
  `file_id` tinyint(4) NOT NULL,
  `header` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `body` text COLLATE utf8_spanish_ci,
  `status` enum('CHECK','OK','DENY') COLLATE utf8_spanish_ci DEFAULT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tos_file`
--

CREATE TABLE `tos_file` (
  `id` tinyint(4) NOT NULL,
  `name` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tos_file`
--

INSERT INTO `tos_file` (`id`, `name`) VALUES
(1, 'ETC.tsv'),
(2, 'INTL.tsv'),
(3, 'ITEM.tsv'),
(4, 'QUEST.tsv'),
(5, 'QUEST_JOBSTEP.tsv'),
(6, 'QUEST_LV_0100.tsv'),
(7, 'QUEST_LV_0200.tsv'),
(8, 'QUEST_LV_0300.tsv'),
(9, 'QUEST_LV_0400.tsv'),
(10, 'QUEST_UNUSED.tsv'),
(11, 'SKILL.tsv'),
(12, 'UI.tsv');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tos_translate`
--

CREATE TABLE `tos_translate` (
  `id` int(11) NOT NULL,
  `base_id` mediumint(9) NOT NULL,
  `user_id` smallint(6) DEFAULT NULL,
  `body` text COLLATE utf8_spanish_ci NOT NULL,
  `coment` text COLLATE utf8_spanish_ci,
  `link` varchar(128) COLLATE utf8_spanish_ci DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `status` enum('EDIT','PUBLIC','ARCHIVED','DELETE') COLLATE utf8_spanish_ci DEFAULT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tos_translate_coment`
--

CREATE TABLE `tos_translate_coment` (
  `id` int(11) NOT NULL,
  `tran_id` int(11) NOT NULL,
  `user_id` smallint(6) NOT NULL,
  `coment` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('UNREAD','READ','ARCHIVED','REMOVED') COLLATE utf8_spanish_ci NOT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `id` smallint(6) NOT NULL,
  `name` varchar(128) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(32) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_spanish_ci NOT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `email`, `creado`, `modificado`) VALUES
(1, 'Ruben Eduardo Tejeda Roa', 'ruben', '164352', 'rubentejedaroa@gmail.com', '2017-11-15 19:32:17', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_like`
--

CREATE TABLE `user_like` (
  `id` int(11) NOT NULL,
  `tran_id` int(11) NOT NULL,
  `user_id` smallint(6) NOT NULL,
  `type` enum('LIKE','DISLIKE') COLLATE utf8_spanish_ci NOT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tos_base`
--
ALTER TABLE `tos_base`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `header` (`header`),
  ADD KEY `tos_base_ibfk_1` (`file_id`);

--
-- Indices de la tabla `tos_file`
--
ALTER TABLE `tos_file`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tos_translate`
--
ALTER TABLE `tos_translate`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `base_id` (`base_id`,`user_id`),
  ADD KEY `tos_translate_ibfk_2` (`user_id`);

--
-- Indices de la tabla `tos_translate_coment`
--
ALTER TABLE `tos_translate_coment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tran_id` (`tran_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `user_like`
--
ALTER TABLE `user_like`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tran_id` (`tran_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tos_base`
--
ALTER TABLE `tos_base`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tos_file`
--
ALTER TABLE `tos_file`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `tos_translate`
--
ALTER TABLE `tos_translate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tos_translate_coment`
--
ALTER TABLE `tos_translate_coment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `user_like`
--
ALTER TABLE `user_like`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tos_base`
--
ALTER TABLE `tos_base`
  ADD CONSTRAINT `tos_base_ibfk_1` FOREIGN KEY (`file_id`) REFERENCES `tos_file` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tos_translate`
--
ALTER TABLE `tos_translate`
  ADD CONSTRAINT `tos_translate_ibfk_1` FOREIGN KEY (`base_id`) REFERENCES `tos_base` (`id`),
  ADD CONSTRAINT `tos_translate_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `tos_translate_coment`
--
ALTER TABLE `tos_translate_coment`
  ADD CONSTRAINT `tos_translate_coment_ibfk_1` FOREIGN KEY (`tran_id`) REFERENCES `tos_translate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tos_translate_coment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `user_like`
--
ALTER TABLE `user_like`
  ADD CONSTRAINT `user_like_ibfk_1` FOREIGN KEY (`tran_id`) REFERENCES `tos_translate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_like_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
